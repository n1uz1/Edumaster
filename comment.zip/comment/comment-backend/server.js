const express = require('express');
const cors = require('cors');
const path = require('path');
const app = express();

const PORT = 3000;

// 启用 CORS
app.use(cors());

// 解析 JSON 请求体
app.use(express.json());

// 内存中的评论数据
let comments = [
  {
    id: 1,
    username: "用户A",
    avatar: "avatar1.jpg",
    content: "这是第一条评论",
    time: new Date().toISOString(),
    likes: 0,
    replies: []
  },
  {
    id: 2,
    username: "用户B",
    avatar: "avatar2.jpg",
    content: "这是第二条评论",
    time: new Date(new Date() - 3600000).toISOString(),
    likes: 0,
    replies: []
  }
];

// 获取所有评论
app.get("/comments", (req, res) => {
  res.json(comments);
});

// 添加新评论
app.post("/comments", (req, res) => {
  const { username, avatar, content } = req.body;
  if (!username || !content || !avatar) {
    return res.status(400).json({ error: "用户名、头像和内容为必填项" });
  }

  const newComment = {
    id: Date.now(),
    username,
    avatar,
    content,
    time: new Date().toISOString(),
    likes: 0,
    replies: []
  };
  comments.push(newComment);
  res.status(201).json(newComment);
});

// 点赞评论
app.post("/comments/:id/like", (req, res) => {
  const commentId = parseInt(req.params.id);
  const comment = comments.find(c => c.id === commentId);

  if (!comment) {
    return res.status(404).json({ error: "评论不存在" });
  }

  comment.likes++;
  res.json(comment);
});

// 添加回复
app.post("/comments/:id/replies", (req, res) => {
  const commentId = parseInt(req.params.id);
  const { username, avatar, content } = req.body;

  if (!username || !content || !avatar) {
    return res.status(400).json({ error: "用户名、头像和内容为必填项" });
  }

  const comment = comments.find(c => c.id === commentId);

  if (!comment) {
    return res.status(404).json({ error: "评论不存在" });
  }

  const newReply = {
    id: Date.now(),
    username,
    avatar,
    content,
    time: new Date().toISOString()
  };

  comment.replies.push(newReply);
  res.status(201).json(newReply);
});

// 删除评论
app.delete("/comments/:id", (req, res) => {
  const commentId = parseInt(req.params.id);
  comments = comments.filter(c => c.id !== commentId);
  res.status(204).send();
});

// 开发模式下不需要提供静态文件，去掉下面的代码
// app.use(express.static(path.join(__dirname, 'dist')));

// 如果没有匹配到任何路由，返回 404 错误
app.use((req, res) => {
  res.status(404).json({ error: "资源未找到" });
});

// 启动服务器
app.listen(PORT, () => {
  console.log(`服务器正在运行在 http://localhost:${PORT}`);
});
