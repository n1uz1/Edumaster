<template>
  <div class="comments">
    <div v-for="(comment, index) in comments" :key="comment.id" class="comment">
      <div class="user-info">
        <img :src="comment.avatar" alt="avatar" class="avatar" />
        <span class="username">{{ comment.username }}</span>
        <span class="timestamp">{{ formatTime(comment.time) }}</span>
      </div>
      <div class="content">{{ comment.content }}</div>
      <div class="actions">
        <button @click="toggleReplies(index)">
          {{ comment.showReplies ? '隐藏回复' : '显示回复' }}
        </button>
        <button @click="likeComment(comment.id, index)">👍 {{ comment.likes }}</button>
        <button @click="replyTo(index)">回复</button>
      </div>
      <div v-if="comment.showReplies" class="replies">
        <div v-for="reply in comment.replies" :key="reply.id" class="reply">
          <div class="user-info">
            <img :src="reply.avatar" alt="avatar" class="avatar" />
            <span class="username">{{ reply.username }}</span>
            <span class="timestamp">{{ formatTime(reply.time) }}</span>
          </div>
          <div class="content">{{ reply.content }}</div>
        </div>
      </div>
      <div v-if="activeCommentIndex === index" class="reply-box">
        <input v-model="replyContent" type="text" placeholder="写下你的回复..." />
        <button @click="sendCommentReply(comment.id, index)">发送</button>
      </div>
    </div>
    <div class="add-comment">
      <input v-model="newComment.content" type="text" placeholder="写下你的评论..." />
      <button @click="addComment">添加评论</button>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      comments: [],
      replyContent: "",
      activeCommentIndex: null,
      newComment: {
        username: "当前用户", // 你可以根据实际登录的用户设置
        avatar: "my-avatar.jpg",
        content: ""
      }
    };
  },
  created() {
    this.fetchComments();
  },
  methods: {
    async fetchComments() {
      try {
        const response = await axios.get("http://localhost:3000/comments");
        this.comments = response.data;
      } catch (error) {
        console.error("获取评论失败", error);
      }
    },
    async addComment() {
      if (!this.newComment.content.trim()) {
        alert("评论内容不能为空");
        return;
      }
      try {
        const response = await axios.post("http://localhost:3000/comments", this.newComment);
        this.comments.push(response.data);
        this.newComment.content = "";
      } catch (error) {
        console.error("添加评论失败", error);
      }
    },
    replyTo(index) {
      this.activeCommentIndex = this.activeCommentIndex === index ? null : index;
      this.replyContent = "";
    },
    async sendCommentReply(commentId, index) {
      if (!this.replyContent.trim()) {
        alert("回复内容不能为空");
        return;
      }
      try {
        const response = await axios.post(`http://localhost:3000/comments/${commentId}/replies`, {
          username: "当前用户", // 根据实际登录的用户设置
          avatar: "my-avatar.jpg",
          content: this.replyContent
        });
        this.comments[index].replies.push(response.data);
        this.replyContent = "";
        this.activeCommentIndex = null;
      } catch (error) {
        console.error("回复失败", error);
      }
    },
    async likeComment(commentId, index) {
      try {
        const response = await axios.post(`http://localhost:3000/comments/${commentId}/like`);
        this.comments[index].likes = response.data.likes;
      } catch (error) {
        console.error("点赞失败", error);
      }
    },
    toggleReplies(index) {
      this.comments[index].showReplies = !this.comments[index].showReplies;
    },
    formatTime(time) {
      const now = new Date();
      const diff = new Date(now) - new Date(time);
      if (diff < 60000) return "刚刚";
      if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`;
      if (diff < 86400000) return `${Math.floor(diff / 3600000)}小时前`;
      return new Date(time).toLocaleDateString();
    }
  }
};
</script>

<style scoped>
.comments {
  width: 600px;
  margin: 0 auto;
}
.comment {
  border-bottom: 1px solid #ccc;
  padding: 10px 0;
}
.replies {
  margin-left: 20px;
  padding-top: 10px;
}
.user-info {
  display: flex;
  align-items: center;
}
.avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  margin-right: 10px;
}
.username {
  font-weight: bold;
  margin-right: 10px;
}
.timestamp {
  color: #999;
}
.content {
  margin: 5px 0;
}
.actions button {
  background: none;
  border: none;
  color: #007bff;
  cursor: pointer;
}
.reply-box {
  display: flex;
  margin-top: 5px;
}
.reply-box input {
  flex: 1;
  padding: 5px;
  margin-right: 5px;
  border: 1px solid #ccc;
}
.reply-box button {
  padding: 5px 10px;
  background-color: #007bff;
  color: white;
  border: none;
  cursor: pointer;
}
.add-comment {
  margin-top: 20px;
  display: flex;
  justify-content: space-between;
}
.add-comment input {
  flex: 1;
  padding: 5px;
  margin-right: 5px;
  border: 1px solid #ccc;
}
.add-comment button {
  padding: 5px 10px;
  background-color: #28a745;
  color: white;
  border: none;
  cursor: pointer;
}
</style>
